/*
# Create waste_scans table

1. New Tables
   - `waste_scans`
     - `id` (uuid, primary key)
     - `waste_item` (text) — name of the waste item the user searched
     - `category` (text) — AI-classified waste category (e.g. Organic, Hazardous, Recyclable)
     - `disposal_instructions` (text) — step-by-step disposal guide
     - `recycling_steps` (text) — recycling procedure instructions
     - `hazard_warnings` (text) — safety hazard information
     - `eco_suggestions` (text) — eco-friendly alternatives or tips
     - `full_response` (jsonb) — raw AI JSON response stored for reference
     - `created_at` (timestamptz) — when the scan was performed

2. Security
   - Enable RLS on `waste_scans`.
   - Single-tenant app with no auth: allow anon + authenticated CRUD so the frontend anon-key client can read/write freely.

3. Notes
   - This is a civic/educational app with no user accounts; all data is intentionally shared/public.
   - USING (true) is acceptable here because all data is intentionally public/shared.
*/

CREATE TABLE IF NOT EXISTS waste_scans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  waste_item text NOT NULL,
  category text NOT NULL DEFAULT 'Unknown',
  disposal_instructions text,
  recycling_steps text,
  hazard_warnings text,
  eco_suggestions text,
  full_response jsonb,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE waste_scans ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_waste_scans" ON waste_scans;
CREATE POLICY "anon_select_waste_scans" ON waste_scans FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_waste_scans" ON waste_scans;
CREATE POLICY "anon_insert_waste_scans" ON waste_scans FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_waste_scans" ON waste_scans;
CREATE POLICY "anon_update_waste_scans" ON waste_scans FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_waste_scans" ON waste_scans;
CREATE POLICY "anon_delete_waste_scans" ON waste_scans FOR DELETE
  TO anon, authenticated USING (true);
