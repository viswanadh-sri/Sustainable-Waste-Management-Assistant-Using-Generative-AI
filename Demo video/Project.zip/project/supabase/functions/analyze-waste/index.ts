import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions";

const SYSTEM_PROMPT = `You are an expert waste management and environmental sustainability advisor.
When given a waste item name, analyze it and respond with a JSON object containing exactly these fields:
{
  "category": "one of: Organic, Recyclable, Hazardous, Electronic (E-Waste), Medical, General, Construction",
  "disposal_instructions": "clear step-by-step disposal instructions as a numbered list",
  "recycling_steps": "detailed recycling procedure if applicable, or 'Not applicable for this waste type'",
  "hazard_warnings": "any safety hazards, health risks, or environmental warnings, or 'No special hazards'",
  "eco_suggestions": "eco-friendly alternatives, tips to reduce this waste, or sustainable practices"
}
Always respond with valid JSON only. No markdown, no code blocks, just the raw JSON object.`;

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const { wasteItem } = await req.json();

    if (!wasteItem || typeof wasteItem !== "string" || wasteItem.trim().length === 0) {
      return new Response(
        JSON.stringify({ error: "wasteItem is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const groqKey = Deno.env.get("GROQ_API_KEY");
    if (!groqKey) {
      return new Response(
        JSON.stringify({ error: "GROQ_API_KEY is not configured" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const groqResponse = await fetch(GROQ_API_URL, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${groqKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "llama-3.3-70b-versatile",
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          { role: "user", content: `Analyze this waste item: ${wasteItem.trim()}` },
        ],
        temperature: 0.3,
        max_tokens: 1024,
      }),
    });

    if (!groqResponse.ok) {
      const errText = await groqResponse.text();
      console.error("Groq API error:", errText);
      return new Response(
        JSON.stringify({ error: "AI service unavailable", detail: errText }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const groqData = await groqResponse.json();
    const rawContent = groqData.choices?.[0]?.message?.content;

    if (!rawContent) {
      return new Response(
        JSON.stringify({ error: "Empty response from AI" }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    let parsed: Record<string, string>;
    try {
      const cleaned = rawContent.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();
      parsed = JSON.parse(cleaned);
    } catch {
      return new Response(
        JSON.stringify({ error: "Failed to parse AI response", raw: rawContent }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const scanRecord = {
      waste_item: wasteItem.trim(),
      category: parsed.category ?? "General",
      disposal_instructions: parsed.disposal_instructions ?? "",
      recycling_steps: parsed.recycling_steps ?? "",
      hazard_warnings: parsed.hazard_warnings ?? "",
      eco_suggestions: parsed.eco_suggestions ?? "",
      full_response: parsed,
    };

    const { data: saved, error: dbError } = await supabase
      .from("waste_scans")
      .insert(scanRecord)
      .select()
      .single();

    if (dbError) {
      console.error("DB insert error:", dbError);
    }

    return new Response(
      JSON.stringify({ success: true, scan: saved ?? scanRecord }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (err) {
    console.error("Edge function error:", err);
    return new Response(
      JSON.stringify({ error: err instanceof Error ? err.message : "Internal error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
