import { AlertTriangle, Recycle, Trash2, Leaf, CheckCircle } from "lucide-react";
import { WasteScan } from "../types";
import CategoryBadge from "./CategoryBadge";

interface WasteResultCardProps {
  scan: WasteScan;
}

function Section({ icon, title, content, accent }: { icon: React.ReactNode; title: string; content: string; accent: string }) {
  return (
    <div className={`rounded-xl border p-4 ${accent}`}>
      <div className="flex items-center gap-2 mb-2">
        {icon}
        <h3 className="font-semibold text-sm text-gray-800">{title}</h3>
      </div>
      <p className="text-sm text-gray-700 leading-relaxed whitespace-pre-line">{content}</p>
    </div>
  );
}

export default function WasteResultCard({ scan }: WasteResultCardProps) {
  return (
    <div className="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden animate-slide-up">
      {/* Header */}
      <div className="bg-gradient-to-r from-green-600 to-emerald-600 px-6 py-5">
        <div className="flex items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <CheckCircle size={16} className="text-green-200" />
              <span className="text-green-100 text-xs font-medium">Analysis Complete</span>
            </div>
            <h2 className="text-white text-xl font-bold capitalize">{scan.waste_item}</h2>
          </div>
          <CategoryBadge category={scan.category as any} />
        </div>
      </div>

      {/* Content */}
      <div className="p-5 grid gap-3">
        <Section
          icon={<Trash2 size={16} className="text-gray-600" />}
          title="Disposal Instructions"
          content={scan.disposal_instructions}
          accent="border-gray-200 bg-gray-50"
        />

        {scan.recycling_steps && scan.recycling_steps !== "Not applicable for this waste type" && (
          <Section
            icon={<Recycle size={16} className="text-blue-600" />}
            title="Recycling Steps"
            content={scan.recycling_steps}
            accent="border-blue-100 bg-blue-50"
          />
        )}

        {scan.hazard_warnings && scan.hazard_warnings !== "No special hazards" && (
          <Section
            icon={<AlertTriangle size={16} className="text-amber-600" />}
            title="Hazard Warnings"
            content={scan.hazard_warnings}
            accent="border-amber-100 bg-amber-50"
          />
        )}

        <Section
          icon={<Leaf size={16} className="text-green-600" />}
          title="Eco-Friendly Suggestions"
          content={scan.eco_suggestions}
          accent="border-green-100 bg-green-50"
        />
      </div>
    </div>
  );
}
