import { WasteCategory } from "../types";

const categoryConfig: Record<WasteCategory, { bg: string; text: string; dot: string }> = {
  Organic: { bg: "bg-lime-100", text: "text-lime-800", dot: "bg-lime-500" },
  Recyclable: { bg: "bg-blue-100", text: "text-blue-800", dot: "bg-blue-500" },
  Hazardous: { bg: "bg-red-100", text: "text-red-800", dot: "bg-red-500" },
  "Electronic (E-Waste)": { bg: "bg-violet-100", text: "text-violet-800", dot: "bg-violet-500" },
  Medical: { bg: "bg-pink-100", text: "text-pink-800", dot: "bg-pink-500" },
  General: { bg: "bg-gray-100", text: "text-gray-700", dot: "bg-gray-400" },
  Construction: { bg: "bg-orange-100", text: "text-orange-800", dot: "bg-orange-500" },
  Unknown: { bg: "bg-gray-100", text: "text-gray-600", dot: "bg-gray-300" },
};

interface CategoryBadgeProps {
  category: WasteCategory;
  size?: "sm" | "md";
}

export default function CategoryBadge({ category, size = "md" }: CategoryBadgeProps) {
  const config = categoryConfig[category] ?? categoryConfig.Unknown;
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full font-semibold ${config.bg} ${config.text}
      ${size === "sm" ? "px-2 py-0.5 text-xs" : "px-3 py-1 text-sm"}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${config.dot}`} />
      {category}
    </span>
  );
}

export { categoryConfig };
