import { Leaf, LayoutDashboard, History, BarChart3, MapPin, Menu, X } from "lucide-react";
import { Page } from "../types";

interface SidebarProps {
  currentPage: Page;
  onNavigate: (page: Page) => void;
  isOpen: boolean;
  onToggle: () => void;
}

const navItems: { page: Page; label: string; icon: React.ComponentType<{ size?: number; className?: string }> }[] = [
  { page: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { page: "history", label: "Scan History", icon: History },
  { page: "analytics", label: "Analytics", icon: BarChart3 },
  { page: "centers", label: "Nearby Centers", icon: MapPin },
];

export default function Sidebar({ currentPage, onNavigate, isOpen, onToggle }: SidebarProps) {
  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/40 backdrop-blur-sm z-20 lg:hidden"
          onClick={onToggle}
        />
      )}

      {/* Mobile menu button */}
      <button
        onClick={onToggle}
        className="fixed top-4 left-4 z-30 lg:hidden bg-green-600 text-white p-2 rounded-lg shadow-lg hover:bg-green-700 transition-colors"
      >
        {isOpen ? <X size={20} /> : <Menu size={20} />}
      </button>

      {/* Sidebar */}
      <aside
        className={`fixed left-0 top-0 h-full w-64 bg-white border-r border-gray-100 shadow-xl z-20 flex flex-col transition-transform duration-300 ease-in-out
          ${isOpen ? "translate-x-0" : "-translate-x-full"} lg:translate-x-0`}
      >
        {/* Logo */}
        <div className="px-6 py-6 border-b border-gray-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl flex items-center justify-center shadow-md">
              <Leaf size={20} className="text-white" />
            </div>
            <div>
              <h1 className="font-bold text-gray-900 text-base leading-tight">EcoWaste AI</h1>
              <p className="text-xs text-green-600 font-medium">Smart City Assistant</p>
            </div>
          </div>
        </div>

        {/* Nav items */}
        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto scrollbar-thin">
          <p className="px-3 pb-2 text-xs font-semibold text-gray-400 uppercase tracking-widest">Navigation</p>
          {navItems.map(({ page, label, icon: Icon }) => {
            const active = currentPage === page;
            return (
              <button
                key={page}
                onClick={() => { onNavigate(page); if (window.innerWidth < 1024) onToggle(); }}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200
                  ${active
                    ? "bg-green-50 text-green-700 shadow-sm"
                    : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
                  }`}
              >
                <span className={`flex-shrink-0 w-8 h-8 rounded-lg flex items-center justify-center transition-colors
                  ${active ? "bg-green-600 text-white" : "bg-gray-100 text-gray-500"}`}>
                  <Icon size={16} />
                </span>
                {label}
                {active && (
                  <span className="ml-auto w-1.5 h-1.5 bg-green-500 rounded-full" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Footer */}
        <div className="px-5 py-4 border-t border-gray-100">
          <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl p-3 border border-green-100">
            <p className="text-xs font-semibold text-green-800">Powered by Groq AI</p>
            <p className="text-xs text-green-600 mt-0.5">LLaMA 3.3 70B Versatile</p>
            <div className="mt-2 flex items-center gap-1.5">
              <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
              <span className="text-xs text-green-700 font-medium">Model Active</span>
            </div>
          </div>
          <p className="text-xs text-gray-400 text-center mt-3">Smart City Sustainability Platform</p>
        </div>
      </aside>
    </>
  );
}
