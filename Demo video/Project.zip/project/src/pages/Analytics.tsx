import { useEffect, useState } from "react";
import { BarChart3, TrendingUp, Recycle, RefreshCw, AlertCircle } from "lucide-react";
import {
  PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer,
  BarChart, Bar, XAxis, YAxis, CartesianGrid,
  LineChart, Line, AreaChart, Area,
} from "recharts";
import { supabase } from "../lib/supabase";
import { WasteScan, WasteCategory } from "../types";

const CATEGORY_COLORS: Record<string, string> = {
  Organic: "#84cc16",
  Recyclable: "#3b82f6",
  Hazardous: "#ef4444",
  "Electronic (E-Waste)": "#8b5cf6",
  Medical: "#ec4899",
  General: "#6b7280",
  Construction: "#f97316",
  Unknown: "#9ca3af",
};

interface DailyStat { date: string; count: number }

function StatCard({ label, value, icon, color }: { label: string; value: string | number; icon: React.ReactNode; color: string }) {
  return (
    <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-5 flex items-center gap-4">
      <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${color}`}>
        {icon}
      </div>
      <div>
        <p className="text-2xl font-bold text-gray-900">{value}</p>
        <p className="text-sm text-gray-500">{label}</p>
      </div>
    </div>
  );
}

export default function Analytics() {
  const [scans, setScans] = useState<WasteScan[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  async function fetchScans() {
    setLoading(true);
    setError(null);
    const { data, error } = await supabase
      .from("waste_scans")
      .select("*")
      .order("created_at", { ascending: true });

    if (error) {
      setError(error.message);
    } else {
      setScans(data ?? []);
    }
    setLoading(false);
  }

  useEffect(() => { fetchScans(); }, []);

  if (loading) {
    return (
      <div className="max-w-5xl mx-auto">
        <h1 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
          <BarChart3 size={24} className="text-green-600" /> Analytics
        </h1>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {[1,2,3,4].map(i => <div key={i} className="h-24 rounded-xl shimmer" />)}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {[1,2,3,4].map(i => <div key={i} className="h-64 rounded-xl shimmer" />)}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="max-w-5xl mx-auto">
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 flex items-center gap-3">
          <AlertCircle size={18} className="text-red-500" />
          <p className="text-red-700 text-sm">{error}</p>
        </div>
      </div>
    );
  }

  // Category distribution
  const categoryCounts: Record<string, number> = {};
  scans.forEach(s => {
    categoryCounts[s.category] = (categoryCounts[s.category] ?? 0) + 1;
  });
  const pieData = Object.entries(categoryCounts).map(([name, value]) => ({ name, value }));

  // Recyclable vs non-recyclable
  const recyclable = scans.filter(s => s.category === "Recyclable" || s.category === "Organic").length;
  const nonRecyclable = scans.length - recyclable;
  const recyclingRate = scans.length > 0 ? Math.round((recyclable / scans.length) * 100) : 0;

  // Hazardous count
  const hazardousCount = scans.filter(s => s.category === "Hazardous" || s.category === "Medical").length;

  // Daily activity (last 14 days)
  const dailyMap: Record<string, number> = {};
  const today = new Date();
  for (let i = 13; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(today.getDate() - i);
    const key = d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
    dailyMap[key] = 0;
  }
  scans.forEach(s => {
    const d = new Date(s.created_at);
    const key = d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
    if (key in dailyMap) dailyMap[key]++;
  });
  const dailyData: DailyStat[] = Object.entries(dailyMap).map(([date, count]) => ({ date, count }));

  // Category bar data
  const barData = Object.entries(categoryCounts)
    .sort((a, b) => b[1] - a[1])
    .map(([category, count]) => ({ category: category.replace(" (E-Waste)", ""), count, fill: CATEGORY_COLORS[category] ?? "#6b7280" }));

  // Recycling bar
  const recyclePieData = [
    { name: "Recyclable", value: recyclable },
    { name: "Non-Recyclable", value: nonRecyclable },
  ];

  return (
    <div className="max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <BarChart3 size={24} className="text-green-600" />
            Analytics
          </h1>
          <p className="text-gray-500 text-sm mt-1">Waste classification insights and trends</p>
        </div>
        <button
          onClick={fetchScans}
          className="flex items-center gap-2 text-sm text-green-700 border border-green-300 px-3 py-1.5 rounded-lg hover:bg-green-50 transition-colors"
        >
          <RefreshCw size={14} />
          Refresh
        </button>
      </div>

      {scans.length === 0 ? (
        <div className="text-center py-16">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <BarChart3 size={28} className="text-gray-400" />
          </div>
          <h3 className="font-semibold text-gray-700 mb-1">No data yet</h3>
          <p className="text-gray-400 text-sm">Analyze some waste items on the Dashboard to see analytics here.</p>
        </div>
      ) : (
        <>
          {/* Stats */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <StatCard
              label="Total Scans"
              value={scans.length}
              icon={<TrendingUp size={22} className="text-white" />}
              color="bg-green-500"
            />
            <StatCard
              label="Recycling Rate"
              value={`${recyclingRate}%`}
              icon={<Recycle size={22} className="text-white" />}
              color="bg-blue-500"
            />
            <StatCard
              label="Categories Found"
              value={Object.keys(categoryCounts).length}
              icon={<BarChart3 size={22} className="text-white" />}
              color="bg-emerald-500"
            />
            <StatCard
              label="Hazardous Items"
              value={hazardousCount}
              icon={<AlertCircle size={22} className="text-white" />}
              color="bg-amber-500"
            />
          </div>

          {/* Charts grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Daily activity */}
            <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-5">
              <h3 className="font-semibold text-gray-800 mb-4 text-sm">Daily Scan Activity (14 days)</h3>
              <ResponsiveContainer width="100%" height={220}>
                <AreaChart data={dailyData}>
                  <defs>
                    <linearGradient id="greenGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#10b981" stopOpacity={0.02} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="date" tick={{ fontSize: 10 }} interval={2} />
                  <YAxis tick={{ fontSize: 10 }} allowDecimals={false} />
                  <Tooltip contentStyle={{ fontSize: 12, borderRadius: "8px" }} />
                  <Area type="monotone" dataKey="count" stroke="#10b981" fill="url(#greenGrad)" strokeWidth={2} name="Scans" />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            {/* Category pie */}
            <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-5">
              <h3 className="font-semibold text-gray-800 mb-4 text-sm">Waste Category Distribution</h3>
              <ResponsiveContainer width="100%" height={220}>
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={55}
                    outerRadius={85}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {pieData.map((entry) => (
                      <Cell key={entry.name} fill={CATEGORY_COLORS[entry.name] ?? "#9ca3af"} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={{ fontSize: 12, borderRadius: "8px" }} />
                  <Legend iconSize={10} wrapperStyle={{ fontSize: 11 }} />
                </PieChart>
              </ResponsiveContainer>
            </div>

            {/* Category bar */}
            <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-5">
              <h3 className="font-semibold text-gray-800 mb-4 text-sm">Scans by Category</h3>
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={barData} layout="vertical" margin={{ left: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" horizontal={false} />
                  <XAxis type="number" tick={{ fontSize: 10 }} allowDecimals={false} />
                  <YAxis dataKey="category" type="category" tick={{ fontSize: 10 }} width={80} />
                  <Tooltip contentStyle={{ fontSize: 12, borderRadius: "8px" }} />
                  <Bar dataKey="count" radius={[0, 4, 4, 0]} name="Scans">
                    {barData.map((entry) => (
                      <Cell key={entry.category} fill={entry.fill} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Recycling breakdown */}
            <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-5">
              <h3 className="font-semibold text-gray-800 mb-4 text-sm">Recycling Statistics</h3>
              <ResponsiveContainer width="100%" height={160}>
                <PieChart>
                  <Pie
                    data={recyclePieData}
                    cx="50%"
                    cy="50%"
                    outerRadius={70}
                    dataKey="value"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    labelLine={false}
                  >
                    <Cell fill="#3b82f6" />
                    <Cell fill="#d1d5db" />
                  </Pie>
                  <Tooltip contentStyle={{ fontSize: 12, borderRadius: "8px" }} />
                </PieChart>
              </ResponsiveContainer>
              <div className="mt-2 grid grid-cols-2 gap-3">
                <div className="bg-blue-50 rounded-lg p-3 text-center border border-blue-100">
                  <p className="text-xl font-bold text-blue-700">{recyclable}</p>
                  <p className="text-xs text-blue-600">Recyclable items</p>
                </div>
                <div className="bg-gray-50 rounded-lg p-3 text-center border border-gray-200">
                  <p className="text-xl font-bold text-gray-600">{nonRecyclable}</p>
                  <p className="text-xs text-gray-500">Non-recyclable items</p>
                </div>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
