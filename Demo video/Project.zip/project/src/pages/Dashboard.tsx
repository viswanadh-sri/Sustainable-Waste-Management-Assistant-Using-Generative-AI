import { useState } from "react";
import { Search, Loader2, Sparkles, ArrowRight, Recycle, Shield, MapPin, Info } from "lucide-react";
import { EDGE_FUNCTION_URL, EDGE_HEADERS } from "../lib/supabase";
import { WasteScan } from "../types";
import WasteResultCard from "../components/WasteResultCard";

const EXAMPLE_ITEMS = [
  "Plastic bottle", "Old smartphone", "Food scraps", "Car battery",
  "Newspaper", "Expired medicines", "Paint cans", "Glass jar",
];

export default function Dashboard() {
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<WasteScan | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function handleAnalyze(item?: string) {
    const wasteItem = (item ?? query).trim();
    if (!wasteItem) return;

    setLoading(true);
    setResult(null);
    setError(null);
    if (item) setQuery(item);

    try {
      const res = await fetch(EDGE_FUNCTION_URL, {
        method: "POST",
        headers: EDGE_HEADERS,
        body: JSON.stringify({ wasteItem }),
      });

      const data = await res.json();

      if (!res.ok || data.error) {
        throw new Error(data.error ?? `Request failed (${res.status})`);
      }

      if (!data.scan) {
        throw new Error("Unexpected response from server");
      }

      setResult(data.scan);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setLoading(false);
    }
  }

  function handleKeyDown(e: React.KeyboardEvent) {
    if (e.key === "Enter") handleAnalyze();
  }

  return (
    <div className="max-w-3xl mx-auto">
      {/* Hero */}
      <div className="text-center mb-8">
        <div className="inline-flex items-center gap-2 bg-green-50 text-green-700 px-4 py-1.5 rounded-full text-sm font-medium mb-4 border border-green-200">
          <Sparkles size={14} />
          AI-Powered Waste Classification
        </div>
        <h1 className="text-3xl lg:text-4xl font-extrabold text-gray-900 mb-3 leading-tight">
          How should you dispose of<br />
          <span className="text-green-600">your waste item?</span>
        </h1>
        <p className="text-gray-500 text-base max-w-xl mx-auto">
          Enter any waste item and get instant AI-generated disposal instructions, recycling guides, hazard warnings, and eco-friendly suggestions.
        </p>
      </div>

      {/* Search bar */}
      <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-4 mb-6">
        <div className="flex gap-3">
          <div className="flex-1 relative">
            <Search size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="e.g. old smartphone, plastic bottle, food scraps..."
              className="w-full pl-10 pr-4 py-3 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all bg-gray-50 focus:bg-white"
            />
          </div>
          <button
            onClick={() => handleAnalyze()}
            disabled={loading || !query.trim()}
            className="flex items-center gap-2 bg-green-600 hover:bg-green-700 disabled:bg-gray-200 disabled:text-gray-400 text-white px-5 py-3 rounded-xl font-semibold text-sm transition-all duration-200 shadow-sm hover:shadow-md disabled:shadow-none"
          >
            {loading ? (
              <>
                <Loader2 size={16} className="animate-spin" />
                Analyzing...
              </>
            ) : (
              <>
                Analyze
                <ArrowRight size={16} />
              </>
            )}
          </button>
        </div>

        {/* Example chips */}
        <div className="mt-3 flex flex-wrap gap-2">
          <span className="text-xs text-gray-400 self-center">Try:</span>
          {EXAMPLE_ITEMS.map((item) => (
            <button
              key={item}
              onClick={() => handleAnalyze(item)}
              disabled={loading}
              className="text-xs px-3 py-1 rounded-full border border-gray-200 text-gray-600 hover:border-green-400 hover:text-green-700 hover:bg-green-50 transition-all disabled:opacity-50"
            >
              {item}
            </button>
          ))}
        </div>
      </div>

      {/* Loading state */}
      {loading && (
        <div className="bg-white rounded-2xl shadow border border-gray-100 p-10 text-center">
          <div className="w-16 h-16 bg-green-50 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse-ring">
            <Recycle size={28} className="text-green-600" />
          </div>
          <h3 className="text-gray-800 font-semibold mb-1">AI is analyzing your waste item</h3>
          <p className="text-gray-500 text-sm">Generating disposal guide with LLaMA 3.3 70B...</p>
          <div className="mt-4 flex justify-center gap-1">
            {[0, 1, 2].map((i) => (
              <span
                key={i}
                className="w-2 h-2 bg-green-400 rounded-full animate-bounce"
                style={{ animationDelay: `${i * 0.15}s` }}
              />
            ))}
          </div>
        </div>
      )}

      {/* Error state */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-2xl p-5 flex items-start gap-3">
          <Info size={18} className="text-red-500 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-red-800 text-sm">Analysis Failed</p>
            <p className="text-red-700 text-sm mt-1">{error}</p>
            <p className="text-red-600 text-xs mt-2">Make sure the GROQ_API_KEY secret is configured.</p>
          </div>
        </div>
      )}

      {/* Result */}
      {result && !loading && <WasteResultCard scan={result} />}

      {/* Info cards when no result */}
      {!result && !loading && !error && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-2">
          {[
            {
              icon: <Recycle size={20} className="text-blue-600" />,
              bg: "bg-blue-50 border-blue-100",
              title: "Smart Classification",
              desc: "AI categorizes waste into Organic, Recyclable, Hazardous, E-Waste, Medical, and more.",
            },
            {
              icon: <Shield size={20} className="text-amber-600" />,
              bg: "bg-amber-50 border-amber-100",
              title: "Safety Warnings",
              desc: "Get hazard alerts and safe handling instructions for dangerous materials.",
            },
            {
              icon: <MapPin size={20} className="text-green-600" />,
              bg: "bg-green-50 border-green-100",
              title: "Find Centers",
              desc: "Locate nearby waste collection and recycling centers on an interactive map.",
            },
          ].map(({ icon, bg, title, desc }) => (
            <div key={title} className={`rounded-xl border p-4 ${bg}`}>
              <div className="w-9 h-9 rounded-lg bg-white shadow-sm flex items-center justify-center mb-3">{icon}</div>
              <h3 className="font-semibold text-gray-800 text-sm mb-1">{title}</h3>
              <p className="text-gray-600 text-xs leading-relaxed">{desc}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
