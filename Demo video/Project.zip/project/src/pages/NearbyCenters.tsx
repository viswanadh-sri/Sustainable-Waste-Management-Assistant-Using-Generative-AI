import { useEffect, useRef, useState } from "react";
import { MapPin, Phone, Clock, Filter, Info } from "lucide-react";
import L from "leaflet";
import { CollectionCenter } from "../types";

// Fix leaflet default marker icons
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
});

const CENTERS: CollectionCenter[] = [
  {
    id: "1", name: "GreenCity Recycling Hub", type: "Recycling Center",
    lat: 28.6139, lng: 77.2090, address: "Connaught Place, New Delhi",
    hours: "Mon–Sat: 8AM–6PM", accepts: ["Paper", "Plastic", "Glass", "Metal"],
    phone: "+91-11-2300-1234",
  },
  {
    id: "2", name: "EcoSafe Hazardous Waste", type: "Hazardous Waste",
    lat: 28.5672, lng: 77.3213, address: "Okhla Industrial Area, Delhi",
    hours: "Mon–Fri: 9AM–5PM", accepts: ["Chemicals", "Paint", "Batteries", "E-Waste"],
    phone: "+91-11-2600-5678",
  },
  {
    id: "3", name: "E-Waste Collection Point", type: "E-Waste",
    lat: 28.6304, lng: 77.2177, address: "Patel Nagar, New Delhi",
    hours: "Tue–Sun: 10AM–7PM", accepts: ["Phones", "Laptops", "Appliances", "Cables"],
    phone: "+91-11-4500-9012",
  },
  {
    id: "4", name: "Organic Compost Facility", type: "Organic",
    lat: 28.5921, lng: 77.1997, address: "Hauz Khas, New Delhi",
    hours: "Daily: 7AM–8PM", accepts: ["Food Waste", "Garden Waste", "Paper"],
    phone: "+91-11-2650-3456",
  },
  {
    id: "5", name: "MediSafe Medical Disposal", type: "Medical Waste",
    lat: 28.6469, lng: 77.2110, address: "Karol Bagh, New Delhi",
    hours: "Mon–Sat: 8AM–4PM", accepts: ["Sharps", "Medicines", "Medical Devices"],
    phone: "+91-11-2870-7890",
  },
  {
    id: "6", name: "Municipal Waste Collection", type: "General Waste",
    lat: 28.6000, lng: 77.2500, address: "Lajpat Nagar, New Delhi",
    hours: "Daily: 6AM–10PM", accepts: ["General Waste", "Bulky Items"],
    phone: "+91-11-1800-111-2222",
  },
  {
    id: "7", name: "Paper & Cardboard Recycler", type: "Recycling Center",
    lat: 28.5500, lng: 77.1800, address: "Vasant Kunj, New Delhi",
    hours: "Mon–Sat: 9AM–6PM", accepts: ["Paper", "Cardboard", "Books", "Newspapers"],
    phone: "+91-11-2680-4321",
  },
  {
    id: "8", name: "Battery Drop-off Point", type: "Hazardous Waste",
    lat: 28.6500, lng: 77.3000, address: "Shahdara, New Delhi",
    hours: "Daily: 8AM–9PM", accepts: ["Batteries", "Bulbs", "CFL Lights"],
    phone: "+91-11-2214-6543",
  },
];

const TYPE_COLORS: Record<string, string> = {
  "Recycling Center": "#3b82f6",
  "Hazardous Waste": "#ef4444",
  "E-Waste": "#8b5cf6",
  Organic: "#84cc16",
  "Medical Waste": "#ec4899",
  "General Waste": "#6b7280",
};

function createMarkerIcon(color: string): L.DivIcon {
  return L.divIcon({
    html: `<div style="background:${color};width:28px;height:28px;border-radius:50% 50% 50% 0;transform:rotate(-45deg);border:3px solid white;box-shadow:0 2px 8px rgba(0,0,0,0.3)"></div>`,
    iconSize: [28, 28],
    iconAnchor: [14, 28],
    popupAnchor: [0, -30],
    className: "",
  });
}

function CenterCard({ center, selected, onClick }: { center: CollectionCenter; selected: boolean; onClick: () => void }) {
  const color = TYPE_COLORS[center.type] ?? "#6b7280";
  return (
    <button
      onClick={onClick}
      className={`w-full text-left bg-white rounded-xl border p-4 transition-all duration-200 hover:shadow-md
        ${selected ? "border-green-400 shadow-md ring-2 ring-green-100" : "border-gray-100 shadow-sm"}`}
    >
      <div className="flex items-start gap-3">
        <div
          className="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5"
          style={{ backgroundColor: `${color}20` }}
        >
          <MapPin size={16} style={{ color }} />
        </div>
        <div className="min-w-0">
          <p className="font-semibold text-gray-900 text-sm leading-tight">{center.name}</p>
          <span
            className="inline-block mt-1 text-xs px-2 py-0.5 rounded-full font-medium"
            style={{ backgroundColor: `${color}15`, color }}
          >
            {center.type}
          </span>
          <div className="mt-2 space-y-1">
            <div className="flex items-center gap-1.5 text-xs text-gray-500">
              <MapPin size={11} className="flex-shrink-0" />
              <span className="truncate">{center.address}</span>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-gray-500">
              <Clock size={11} className="flex-shrink-0" />
              {center.hours}
            </div>
            <div className="flex items-center gap-1.5 text-xs text-gray-500">
              <Phone size={11} className="flex-shrink-0" />
              {center.phone}
            </div>
          </div>
          <div className="mt-2 flex flex-wrap gap-1">
            {center.accepts.slice(0, 3).map(a => (
              <span key={a} className="text-xs bg-gray-100 text-gray-600 px-1.5 py-0.5 rounded">{a}</span>
            ))}
            {center.accepts.length > 3 && (
              <span className="text-xs bg-gray-100 text-gray-500 px-1.5 py-0.5 rounded">+{center.accepts.length - 3} more</span>
            )}
          </div>
        </div>
      </div>
    </button>
  );
}

export default function NearbyCenters() {
  const mapRef = useRef<L.Map | null>(null);
  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const markersRef = useRef<Record<string, L.Marker>>({});
  const [selected, setSelected] = useState<string | null>(null);
  const [typeFilter, setTypeFilter] = useState<string>("All");

  const centerTypes = ["All", ...Array.from(new Set(CENTERS.map(c => c.type)))];
  const filtered = typeFilter === "All" ? CENTERS : CENTERS.filter(c => c.type === typeFilter);

  function flyTo(center: CollectionCenter) {
    setSelected(center.id);
    if (mapRef.current) {
      mapRef.current.flyTo([center.lat, center.lng], 15, { duration: 1.2 });
      markersRef.current[center.id]?.openPopup();
    }
  }

  useEffect(() => {
    if (!mapContainerRef.current || mapRef.current) return;

    mapRef.current = L.map(mapContainerRef.current).setView([28.6139, 77.2090], 12);

    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
      maxZoom: 19,
    }).addTo(mapRef.current);

    CENTERS.forEach(center => {
      const color = TYPE_COLORS[center.type] ?? "#6b7280";
      const marker = L.marker([center.lat, center.lng], { icon: createMarkerIcon(color) })
        .addTo(mapRef.current!)
        .bindPopup(`
          <div style="min-width:200px">
            <div style="font-weight:700;font-size:14px;color:#111;margin-bottom:4px">${center.name}</div>
            <div style="font-size:11px;color:${color};font-weight:600;margin-bottom:8px">${center.type}</div>
            <div style="font-size:12px;color:#555;margin-bottom:2px">📍 ${center.address}</div>
            <div style="font-size:12px;color:#555;margin-bottom:2px">🕐 ${center.hours}</div>
            <div style="font-size:12px;color:#555;margin-bottom:8px">📞 ${center.phone}</div>
            <div style="font-size:11px;color:#666">Accepts: ${center.accepts.join(", ")}</div>
          </div>
        `);

      marker.on("click", () => setSelected(center.id));
      markersRef.current[center.id] = marker;
    });

    return () => {
      mapRef.current?.remove();
      mapRef.current = null;
      markersRef.current = {};
    };
  }, []);

  return (
    <div className="max-w-6xl mx-auto">
      {/* Header */}
      <div className="mb-5">
        <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
          <MapPin size={24} className="text-green-600" />
          Nearby Collection Centers
        </h1>
        <p className="text-gray-500 text-sm mt-1">Find waste collection and recycling centers near you</p>
      </div>

      {/* Info banner */}
      <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 flex items-start gap-2 mb-5">
        <Info size={15} className="text-blue-500 flex-shrink-0 mt-0.5" />
        <p className="text-blue-700 text-xs">
          Sample collection centers shown for demonstration. In production, these are loaded from a real database using your city's waste management API. Click a center card or map marker for details.
        </p>
      </div>

      <div className="flex flex-col lg:flex-row gap-4 h-[calc(100vh-260px)] min-h-[500px]">
        {/* Sidebar list */}
        <div className="w-full lg:w-80 flex flex-col gap-3 overflow-hidden">
          {/* Filter */}
          <div className="flex items-center gap-2">
            <Filter size={14} className="text-gray-500 flex-shrink-0" />
            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              className="flex-1 text-sm border border-gray-200 rounded-lg px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-green-500 bg-white"
            >
              {centerTypes.map(t => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>
          </div>
          <p className="text-xs text-gray-400">{filtered.length} centers found</p>

          {/* Center list */}
          <div className="flex-1 overflow-y-auto space-y-2 scrollbar-thin pr-1">
            {filtered.map(center => (
              <CenterCard
                key={center.id}
                center={center}
                selected={selected === center.id}
                onClick={() => flyTo(center)}
              />
            ))}
          </div>
        </div>

        {/* Map */}
        <div className="flex-1 rounded-2xl overflow-hidden border border-gray-200 shadow-md min-h-[350px]">
          <div ref={mapContainerRef} className="w-full h-full" />
        </div>
      </div>
    </div>
  );
}
