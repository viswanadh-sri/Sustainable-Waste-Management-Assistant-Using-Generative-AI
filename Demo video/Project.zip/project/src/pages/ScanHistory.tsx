import { useEffect, useState } from "react";
import { History, Search, Trash2, RefreshCw, ChevronDown, ChevronUp, AlertCircle } from "lucide-react";
import { supabase } from "../lib/supabase";
import { WasteScan } from "../types";
import CategoryBadge from "../components/CategoryBadge";

export default function ScanHistory() {
  const [scans, setScans] = useState<WasteScan[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [deleting, setDeleting] = useState<string | null>(null);

  async function fetchScans() {
    setLoading(true);
    setError(null);
    const { data, error } = await supabase
      .from("waste_scans")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(100);

    if (error) {
      setError(error.message);
    } else {
      setScans(data ?? []);
    }
    setLoading(false);
  }

  async function deleteScan(id: string) {
    setDeleting(id);
    const { error } = await supabase.from("waste_scans").delete().eq("id", id);
    if (!error) {
      setScans((prev) => prev.filter((s) => s.id !== id));
      if (expandedId === id) setExpandedId(null);
    }
    setDeleting(null);
  }

  useEffect(() => { fetchScans(); }, []);

  const filtered = scans.filter((s) =>
    s.waste_item.toLowerCase().includes(search.toLowerCase()) ||
    s.category.toLowerCase().includes(search.toLowerCase())
  );

  function formatDate(iso: string) {
    return new Date(iso).toLocaleString("en-US", {
      month: "short", day: "numeric", year: "numeric",
      hour: "2-digit", minute: "2-digit",
    });
  }

  return (
    <div className="max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <History size={24} className="text-green-600" />
            Scan History
          </h1>
          <p className="text-gray-500 text-sm mt-1">All previously analyzed waste items</p>
        </div>
        <button
          onClick={fetchScans}
          disabled={loading}
          className="flex items-center gap-2 text-sm text-green-700 border border-green-300 px-3 py-1.5 rounded-lg hover:bg-green-50 transition-colors disabled:opacity-50"
        >
          <RefreshCw size={14} className={loading ? "animate-spin" : ""} />
          Refresh
        </button>
      </div>

      {/* Search */}
      <div className="relative mb-4">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search by item name or category..."
          className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent bg-white"
        />
      </div>

      {/* States */}
      {loading && (
        <div className="space-y-3">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-16 rounded-xl shimmer" />
          ))}
        </div>
      )}

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 flex items-center gap-3">
          <AlertCircle size={18} className="text-red-500" />
          <p className="text-red-700 text-sm">{error}</p>
        </div>
      )}

      {!loading && !error && filtered.length === 0 && (
        <div className="text-center py-16">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <History size={28} className="text-gray-400" />
          </div>
          <h3 className="font-semibold text-gray-700 mb-1">
            {search ? "No matching scans" : "No scans yet"}
          </h3>
          <p className="text-gray-400 text-sm">
            {search ? "Try a different search term." : "Go to the Dashboard and analyze a waste item to get started."}
          </p>
        </div>
      )}

      {/* List */}
      {!loading && !error && (
        <div className="space-y-2">
          {filtered.map((scan) => {
            const expanded = expandedId === scan.id;
            return (
              <div key={scan.id} className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden transition-all duration-200 hover:shadow-md">
                {/* Row */}
                <div className="flex items-center gap-4 px-4 py-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-semibold text-gray-900 text-sm capitalize">{scan.waste_item}</span>
                      <CategoryBadge category={scan.category as any} size="sm" />
                    </div>
                    <p className="text-xs text-gray-400 mt-0.5">{formatDate(scan.created_at)}</p>
                  </div>

                  <div className="flex items-center gap-2 flex-shrink-0">
                    <button
                      onClick={() => setExpandedId(expanded ? null : scan.id)}
                      className="flex items-center gap-1 text-xs text-green-700 border border-green-200 px-2.5 py-1 rounded-lg hover:bg-green-50 transition-colors"
                    >
                      {expanded ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
                      {expanded ? "Less" : "Details"}
                    </button>
                    <button
                      onClick={() => deleteScan(scan.id)}
                      disabled={deleting === scan.id}
                      className="p-1.5 rounded-lg text-gray-400 hover:text-red-500 hover:bg-red-50 transition-colors disabled:opacity-50"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>

                {/* Expanded details */}
                {expanded && (
                  <div className="border-t border-gray-100 px-4 py-4 space-y-3 bg-gray-50">
                    {[
                      { label: "Disposal Instructions", value: scan.disposal_instructions },
                      { label: "Recycling Steps", value: scan.recycling_steps },
                      { label: "Hazard Warnings", value: scan.hazard_warnings },
                      { label: "Eco Suggestions", value: scan.eco_suggestions },
                    ].filter(({ value }) => value && value !== "Not applicable for this waste type" && value !== "No special hazards").map(({ label, value }) => (
                      <div key={label}>
                        <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">{label}</p>
                        <p className="text-sm text-gray-700 leading-relaxed whitespace-pre-line">{value}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Count */}
      {!loading && !error && scans.length > 0 && (
        <p className="text-center text-xs text-gray-400 mt-4">
          Showing {filtered.length} of {scans.length} scans
        </p>
      )}
    </div>
  );
}
