export interface WasteScan {
  id: string;
  waste_item: string;
  category: WasteCategory;
  disposal_instructions: string;
  recycling_steps: string;
  hazard_warnings: string;
  eco_suggestions: string;
  full_response: Record<string, string> | null;
  created_at: string;
}

export type WasteCategory =
  | "Organic"
  | "Recyclable"
  | "Hazardous"
  | "Electronic (E-Waste)"
  | "Medical"
  | "General"
  | "Construction"
  | "Unknown";

export type Page = "dashboard" | "history" | "analytics" | "centers";

export interface CollectionCenter {
  id: string;
  name: string;
  type: string;
  lat: number;
  lng: number;
  address: string;
  hours: string;
  accepts: string[];
  phone: string;
}
