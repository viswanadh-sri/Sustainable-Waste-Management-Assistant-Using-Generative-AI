import { useState } from "react";
import Sidebar from "./components/Sidebar";
import Dashboard from "./pages/Dashboard";
import ScanHistory from "./pages/ScanHistory";
import Analytics from "./pages/Analytics";
import NearbyCenters from "./pages/NearbyCenters";
import { Page } from "./types";

const PAGE_TITLES: Record<Page, string> = {
  dashboard: "Waste Classifier",
  history: "Scan History",
  analytics: "Analytics Dashboard",
  centers: "Collection Centers",
};

export default function App() {
  const [page, setPage] = useState<Page>("dashboard");
  const [sidebarOpen, setSidebarOpen] = useState(false);

  function navigate(p: Page) {
    setPage(p);
    setSidebarOpen(false);
  }

  return (
    <div className="min-h-screen bg-gray-50 flex">
      <Sidebar
        currentPage={page}
        onNavigate={navigate}
        isOpen={sidebarOpen}
        onToggle={() => setSidebarOpen(o => !o)}
      />

      {/* Main content */}
      <main className="flex-1 lg:ml-64 min-h-screen flex flex-col">
        {/* Top bar */}
        <header className="sticky top-0 z-10 bg-white/80 backdrop-blur-md border-b border-gray-100 px-6 py-3 flex items-center gap-4">
          <div className="w-8 lg:hidden" /> {/* spacer for mobile hamburger */}
          <div>
            <h2 className="font-bold text-gray-900 text-base">{PAGE_TITLES[page]}</h2>
            <p className="text-xs text-gray-400">Smart City Waste Management Platform</p>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <span className="hidden sm:flex items-center gap-1.5 text-xs text-green-700 bg-green-50 border border-green-200 px-2.5 py-1 rounded-full font-medium">
              <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse" />
              AI Ready
            </span>
          </div>
        </header>

        {/* Page content */}
        <div className="flex-1 p-4 sm:p-6 overflow-auto">
          {page === "dashboard" && <Dashboard />}
          {page === "history" && <ScanHistory />}
          {page === "analytics" && <Analytics />}
          {page === "centers" && <NearbyCenters />}
        </div>

        {/* Footer */}
        <footer className="border-t border-gray-100 px-6 py-3 text-center">
          <p className="text-xs text-gray-400">
            EcoWaste AI &mdash; Sustainable Waste Management Assistant &bull; Powered by Groq LLaMA 3.3 70B &bull; OpenStreetMap
          </p>
        </footer>
      </main>
    </div>
  );
}
